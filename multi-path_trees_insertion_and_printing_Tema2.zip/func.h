#ifndef __FUNC_H__
#define __FUNC_H__

int verifica_win(char **matrix, int n, int m, int x, int y)
{
	int j = 0, c;
	//cautam 3 elemnte la fel cu cel de pe pozita
	//primita pentru a verfica daca se ajunge la
	//victorie

	//verdical

	for (c = 1; c <= 3; c++) {
		//conditii sa nu se depaseasca
		//dimensiunile matricei
		if (x+c < n) {
			if (matrix[x][y] == matrix[x+c][y]) {
				j++;
				if (j == 3)
					return 1;
			} else
				break;
		} else
			break;
	}

	for (c = 1; c <= 3; c++) {
		//conditii sa nu se depaseasca
		//dimensiunile matricei
		if (x-c >= 0) {
			if (matrix[x][y] == matrix[x - c][y]) {
				j++;
				if (j == 3)
					return 1;
			} else
				break;
		} else
			break;
	}

	j = 0;
	//orizontala

	for (c = 1; c <= 3; c++) {
		//conditii sa nu se depaseasca
		//dimensiunile matricei
		if (y + c < m) {
			if (matrix[x][y] == matrix[x][y + c]) {
				j++;
				if (j == 3)
					return 1;
			} else
				break;
		} else
			break;
	}
	for (c = 1; c <= 3; c++) {
		//conditii sa nu se depaseasca
		//dimensiunile matricei
		if (y - c >= 0) {
			if (matrix[x][y] == matrix[x][y - c]) {
				j++;
				if (j == 3)
					return 1;
			} else
				break;
		} else
			break;
	}

	j = 0;
	//diagonala principala

	for (c = 1; c <= 3; c++) {
		//conditii sa nu se depaseasca
		//dimensiunile matricei
		if (y - c >= 0 && x - c >= 0) {
			if (matrix[x][y] == matrix[x - c][y - c]) {
				j++;
				if (j == 3)
					return 1;
			} else
				break;

		} else
			break;
	}

	for (c = 1; c <= 3; c++) {
		//conditii sa nu se depaseasca
		//dimensiunile matricei
		if (x + c < n && y + c < m) {
			if (matrix[x][y] == matrix[x + c][y + c]) {
				j++;
				if (j == 3)
					return 1;
			} else
				break;
		} else
			break;
	}

	j = 0;
	//diagonala secundara

	for (c = 1; c <= 3; c++) {
		//conditii sa nu se depaseasca
		//dimensiunile matricei
		if (y + c < m && x - c >= 0) {
			if (matrix[x][y] == matrix[x - c][y + c]) {
				j++;
				if (j == 3)
					return 1;
			} else
				break;

		} else
			break;
	}

	for (c = 1; c <= 3; c++) {
		//conditii sa nu se depaseasca
		//dimensiunile matricei
		if (y - c >= 0 && x + c < n) {
			if (matrix[x][y] == matrix[x + c][y - c]) {
				j++;
				if (j == 3)
					return 1;
			} else
				break;

		} else
			break;
	}
	return 0;
}
//alocam un nod de arbore care are matricea trimisa de noi
arbore *nod_arbore_nou(char **matrix, int n, int m)
{
	//memorie pentru nod
	struct arbore *nou = malloc(sizeof(*nou));
	//memorie pentru liniile din matrice
	nou->matrix = (char **)malloc(sizeof(char *)*n);
	//memorie pentru coloanele din matrice
	for (int k = 0; k < n; k++)
		(nou->matrix)[k] = (char *)malloc(sizeof(char)*m);
	nou->next = nou->list = NULL;
	//copeiem matricea
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++)
			nou->matrix[i][j] = matrix[i][j];
	}
	return nou;
}
//punem nodul curent in lista
void pune_nod_la_final_de_lista(arbore **sp, char **matrix, int n, int m)
{
	//verificam daca nodul exista
	if (!(*sp))
		return;
	arbore *ac = *sp;
	//parcurgem lista si punem la final
	while (ac->next)
		ac = ac->next;
	ac->next = nod_arbore_nou(matrix, n, m);
}
//punem nodul in lista sau creem lista
void adauga_in_lista_din_nodul_curent(arbore **sp, char **matrix, int n, int m)
{
	//verificam daca nodul curent exista
	if (!(*sp))
		return;
	//verificam daca lista exista sau nu
	if ((*sp)->list)
		pune_nod_la_final_de_lista(&((*sp)->list), matrix, n, m);
	else
		(*sp)->list = nod_arbore_nou(matrix, n, m);
}

//eliberam memoria
void func_elibereaza(arbore *sp, int n)
{
	//verificam daca nodul exista
	if (!sp)
		return;
	//reapelam functia pentru lista
	//din nodul curent
	func_elibereaza(sp->list, n);
	//reapelam pentru urmatorul element
	func_elibereaza(sp->next, n);
	//eliberam memoria alocata matricei
	for (int i = 0; i < n; i++)
		free(sp->matrix[i]);
	free(sp->matrix);
	//eliberam memoria alocata nodului
	free(sp);
}
// printam arborele in fisier
void pune_in_fisier_arborele(arbore *root, int n, int m,
int nr, FILE *fis_out)
{
	//verificam daca nodul curent exist
	if (!root)
		return;
	while (root) {
		//printam matricea si numarul de tab-uri
		for (int i = 0; i < n; i++) {
			for (int c = 0; c < nr; c++)
				fprintf(fis_out, "%s", "\t");
			for (int j = 0; j < m; j++)
				if (j == m - 1)
					fprintf(fis_out, "%c",
					 root->matrix[i][j]);
				else
					fprintf(fis_out, "%c ",
					 root->matrix[i][j]);
			fprintf(fis_out, "%s", "\n");
		}
		fprintf(fis_out, "%s", "\n");
		if (root->list) {
			nr = nr + 1;
			//reapelam functia daca exista o lista in nodul curent
			pune_in_fisier_arborele(root->list, n, m, nr, fis_out);
			nr = nr - 1;
			}
		root = root->next;
	}
}
//creem matricile de joc si le punem in arbore
void arborele(int n, int m, char *mutare, char **matrix, arbore **sp)
{
	int v[m], i, j;
	char *c;
	//c reprezinta mutarea urmatoare
	//v reprezinta vectorul pentru coloanele in care au cazut bile
	for (i = 0; i < m; i++)
		v[i] = 0;
	if (strcmp(mutare, "R") == 0)
		c = "B";
	else
		c = "R";
	//parcurgem matricea primita
	for (j = 0; j < m; j++)
		for (i = n - 1; i >= 0 ; i--) {
			//cautam elemntul "-" si verificam
			// coloana pe care e gasit
			if (matrix[i][j] == '-' && v[j] == 0) {
				//completam cu mutarea corespunzatoare
				matrix[i][j] = *mutare;
				//verificam daca sa terminat jocul
				if (verifica_win(matrix, n, m, i, j)) {
					//daca da punem matricea in arbore
					v[j] = 1;
					adauga_in_lista_din_nodul_curent(&(*sp),
					 matrix, n, m);
					//punem din nou elementul "-"
					matrix[i][j] = '-';
				} else {
					//daca nu punem matricea si repelam
					//functia pentru urmatoarea matrice
					adauga_in_lista_din_nodul_curent(&(*sp),
					 matrix, n, m);
					arbore *ac = (*sp)->list;
					//parcurgem pana la ultimul element
					// din lista in care ne aflam deoarece
					// matricea urmatoare ii va
					//apartine lui
					while (ac->next)
						ac = ac->next;
					arborele(n, m, c, matrix, &ac);
					//punem din nou elementul "-"
					matrix[i][j] = '-';
					v[j] = 1;
				}
			}
		}
}

#endif
