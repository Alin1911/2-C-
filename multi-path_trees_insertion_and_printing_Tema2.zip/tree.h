#ifndef __TREE_H__
#define __TREE_H__

typedef struct arbore {
	//matricea curenta
	char **matrix;
	//lista de posibiltati de a muta
	struct arbore *list;
	//urmatorul element in lista
	struct arbore *next;

} arbore;


//functie care verifica daca jocul a fost castigat(1)
int verifica_win(char **matrix, int n, int m, int x, int y);
//functie care aloca un nod pentru arbore si pune in el matricea(2)
arbore *nod_arbore_nou(char **matrix, int n, int m);
//functie care pune un nod la finalul listei din nodul curent(3)
void pune_nod_la_final_de_lista(arbore **sp, char **matrix, int n, int m);
//functie care pune in lista din nodul curent sau creeaza lista
//apeland functia (3) sau (2)
void adauga_in_lista_din_nodul_curent(arbore **sp, char **matrix, int n, int m);
//functie care elibereaza memoria
void func_elibereaza(arbore *sp, int n);
//functie care printeaza in fisier arborele
void pune_in_fisier_arborele(arbore *root, int n, int m, int nr, FILE *fis_out);
//functie recursiva ce calculeaza probabilitatile si compune matricile de joc
void arborele(int n, int m, char *mutare, char **matrix, arbore **sp);

#endif
