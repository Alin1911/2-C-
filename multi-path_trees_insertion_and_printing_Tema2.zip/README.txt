Andrei Alin-Ionuț 313CC Tema2_SD

Tema e compusa din 3 fisiere, primul se numeste "tree.h" ce contine antetele
functiilor si arborele folosit, al 2-lea "func.h" contine implementarea 
functiilor iar al 3-lea "main.c" contine functia "main".

Cerinta 1

Am o stuctura de arbore multicai cu numele "arbore" ce contine 2 pointeri de tip
"arbore" unul "list" pentru lista si unul "next" pentru elemntul urmator si un 
dublu pointer de tip char pentru matrice.

In main am citit din fisier caracter cu caracter si am mutat cursorul de unde 
trebuia sa citesc, am alocat memorie pentru matrice si am citit elementele ei 
cautand doar elemnte ca "B", "R" si "-", apoi au fost apelate functiile pentru 
a construi arborele:

	1. Functia "nod_arbore_nou" ce primeste ca parametri de intrare matricea si 
	dimensiunile ei, si returneaza un nod de arbore. ea aloca memorie pentru nod
	apoi pentru amtrice si copiaza element element din matricea primita ca 
	aprametru in cea din noul nod.

	2. Functia "pune_nod_la_final_de_lista", ea primeste ca paramtru nodul ce 
	contine lista in care dorim sa punem matricea, parcurge acceasta lista si la
	final foloseste functia "nod_arbore_nou" pentru a crea nodul pe care il pune
	la final.

	3. Functia "adauga_in_lista_din_nodul_curent" ce se foloseste de primele 
	doua functii pentru a creea sau pune in lista matricea trimisa ca parametru,
	 ea testand si cazul in care lista nu exista.

	4. Functia "verifica_win" ce primeste ca parametri matricea si dimensiunile 
	ei si unde a fost ultima data completat apoi testeaza diagonalele, si pe 
	orizontal si verdical daca pe langa aceasta pozitie unde a fost completat 
	ultima data mai sunt 3 elemente la fel, daca se gasesc returneaza "1" daca 
	nu returneaza "0",

	5.Functia "arborele" e functia ce creeaza matricile din arbore si apeleaza 
	celelalte functii pentru a pune elemntele in arbore. Ea primeste ca 
	parametri matricea, arborele,dimensiunile amtricei si urmatoarea mutare, am 
	luat un vector pentru a stoca in el coloanele ce au fost deja completate, 
	deoarece nu poti pune intr-a singua matrice 2 bile pe acceasi linie, apoi am
	parcurs matricea din coltul din stanga jos urcand mereu si crescand numarul
	coloanei, in aceasta parcurgere am verificat daca se gasesc elemnte ca "-",
	daca da si coloana se afla in vector cu valoarea "0", am completat cu 
	mutarea si apoi am verificat daca sa ajuns la victorie daca da se parcurge 
	lista din arborele curent si se pune nodul cu acea matrice noua la final, 
	daca nu se parcurge lista si se pune pune nodul cu acea matrice noua la 
	finalul listei apoi se reapeleaza functia "arborele" pentru a continua 
	compunerea matricilor de joc, apoi se repune pe acea pozitie elementul "-".

	6. Functia "pune_in_fisier_arborele" ce printeaza in fisier arborele de joc,
	ea are ca parmatri de intrare arborele, dimensiunile matricei, fisierul in 
	care se scrie si un elemnt de tip int ce reprezinta numarul de "tab-uri" ce
	creste o data cu adancimea. Ea verifica cat timp arborele exista printeaza
	matricea din el apoi verifica daca exista o lista in el in cazul acesta 
	se reapeleaza, si parcurge in acest cat timp lista curenta prin pointerul 
	next printand matricile si tab-urile. 

	7. Functia "func_elibereaza" ce elibereaza memoria alocata arborelui astfel,
	prima data se reapeleaza functia pentru mrmatoarea lista apoi pentru 
	urmatorul element, conditia de oprire e ca acsti pointeri sa existe, si 
	dupa acste reapelari are loc eliberarea memoriei pentru matrice si pentru 
	pointerul nodului.

Dupa acste functii este eliberata memori pentru matricea alocata in functia 
"main" si este inchis fisierul in care se scrie.