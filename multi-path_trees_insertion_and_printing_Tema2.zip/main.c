#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include "tree.h"
#include "func.h"

void main(int argc, char **argv)
{
	//verifica task
	if (strcmp(argv[1], "-c1") != 0)
		return;

	//deschid fisierele
	FILE *fis;
	FILE *fis_out = fopen(argv[argc-1], "w+");
	int m, n, i = 0, j = 0, k = 0;
	char mutare[0], **matrix, c[0];

	fis = fopen(argv[2], "r");
	//citesc caracter cu caracter
	n = fgetc(fis) - 48;
	//mut cursorul in fisier
	fseek(fis, 2, SEEK_SET);
	m = fgetc(fis) - 48;
	//aloc memorie pentru matrice
	matrix =  (char **)malloc(sizeof(char *)*n);
	for (k = 0; k < n; k++)
		matrix[k] = (char *)malloc(sizeof(char)*m);
	//mut cursorul
	fseek(fis, 4, SEEK_SET);
	mutare[0] = fgetc(fis);
	//citesc matricea din fisier
	fseek(fis, 6, SEEK_SET);
	while (1) {
		c[0] = fgetc(fis);
		//caut elementele matricei
		if (c[0] == EOF)
			break;
		else if (strcmp(c, "B") == 0 || strcmp(c, "R") == 0 ||
		 strcmp(c, "-") == 0) {
			matrix[i][j] = c[0];
			j++;
			if (j == m) {
				i++;
				j = 0;
			}
			if (i == n)
				break;
		}
	}
	//inchid fisierul de citire
	fclose(fis);
	c[0] = mutare[0];
	//creez primul nod
	struct arbore *CON4 = nod_arbore_nou(matrix, n, m);
	//creez arborele
	arborele(n, m, c, matrix, &CON4);
	//scriu in fisier arborle
	pune_in_fisier_arborele(CON4, n, m, 0, fis_out);
	//eliberez memoria arborelui
	func_elibereaza(CON4, n);
	//inchid fisierul in care scriu
	fclose(fis_out);
	//eliberez memoria matricei
	for (i = 0; i < n; i++)
		free(matrix[i]);
	free(matrix);
}
